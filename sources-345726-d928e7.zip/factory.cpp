#include <boost/function.hpp>
#include <boost/functional/factory.hpp>

#include <iostream>
#include <map>
#include <string>

struct Shape {

	virtual ~Shape(){};

	virtual void draw() = 0;
};

struct Circle : Shape {
	void draw() override {
		std::cout << "circle" << std::endl;
	}
};

struct Box : Shape {
	void draw() override {
		std::cout << "box" << std::endl;
	}
};

int main() {
	std::map<std::string, boost::function<Shape *()>> factories;

	factories["circle"] = boost::factory<Circle*>();
	factories["box"] = boost::factory<Box *>();

	auto c = std::unique_ptr<Shape>{ factories["circle"]() };
	c->draw();

	auto b = std::unique_ptr<Shape>{ factories["box"]() };
	b->draw();
}
