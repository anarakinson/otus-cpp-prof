#include <boost/fusion/include/adapt_struct.hpp>
#include <boost/fusion/include/at_c.hpp>
#include <boost/fusion/include/for_each.hpp>
#include <boost/fusion/include/mpl.hpp>
#include <boost/mpl/range_c.hpp>

#include <boost/fusion/include/adapt_adt.hpp>

#include <iostream>
#include <string>

namespace fusion = boost::fusion;
namespace mpl = boost::mpl;

namespace basics {
    struct MyStruct {
        double val1;
        double val2;
        char letter;
        int number;
    };

} // namespace basics

// Should be in the global namespace
BOOST_FUSION_ADAPT_STRUCT(
    basics::MyStruct,
    (double, val1)(double, val2)(char, letter)(int, number))

namespace basics {

    template <typename Sequence>
    struct XmlFieldNamePrinter {
        XmlFieldNamePrinter(const Sequence& seq)
            :seq_(seq) {
        }

        template <typename Index>
        void operator()(Index /*idx*/) const {
            const std::string field_name =
                fusion::extension::struct_member_name<Sequence, Index::value>::call();

            std::cout
                << '<' << field_name << '>'
                << fusion::at<Index>(seq_)
                << "</" << field_name << '>';
        }

    private:
        const Sequence& seq_;
    };

    template <typename Sequence>
    void printXml(Sequence const& v) {
        typedef mpl::range_c<unsigned, 0, fusion::result_of::size<Sequence>::value> Indices;
        fusion::for_each(Indices(), XmlFieldNamePrinter<Sequence>(v));

        // XmlFieldNamePrinter<Sequence> x(v);
        // x(0); x(1); ...
    }

    void example() {
        std::cout << "*****     basics example    ****" << std::endl;
        MyStruct saveMe = {3.4, 5.6, 'g', 9};
        printXml(saveMe);
    }

} // namespace basics

namespace advanced {

    struct StructWithPrivate {
        StructWithPrivate(const std::string& str, uint32_t val)
            :m_str{str}, m_val{val} {
        }

        const std::string& getStr() const {
            return m_str;
        }

        void setStr(const std::string& str) {
            m_str = str;
        }

        uint32_t getVal() const {
            return m_val;
        }

        void setVal(uint32_t val) {
            m_val = val;
        }

        uint64_t getID() const {
            return m_id;
        }

    private:
        std::string m_str;
        uint64_t m_id; // auto-generated UUID
        uint32_t m_val;
    };

} // namespace advanced

BOOST_FUSION_ADAPT_ADT(
    advanced::StructWithPrivate,
    (const std::string &, const std::string &, obj.getStr(), obj.setStr(val))
    (uint32_t, uint32_t, obj.getVal(), obj.setVal(val))
)

#define CUSTOM_ADT_MEMBER_NAME(CLASSNAME, IDX, MEMBERNAME)     \
    namespace boost {                                          \
        namespace fusion {                                     \
            namespace extension {                              \
                template <>                                    \
                struct struct_member_name<CLASSNAME, IDX> {    \
                    typedef char const *type;                  \
                    static type call() { return #MEMBERNAME; } \
                };                                             \
            }                                                  \
        }                                                      \
    }
CUSTOM_ADT_MEMBER_NAME(advanced::StructWithPrivate, 0, m_str)
CUSTOM_ADT_MEMBER_NAME(advanced::StructWithPrivate, 1, m_val)

namespace advanced {

    template <typename Sequence>
    struct JsonFieldNamePrinter {
        JsonFieldNamePrinter(const Sequence& seq)
            :seq_(seq) {
        }

        template <typename Index>
        void operator()(Index idx) const {
            if (idx != 0) {
                std::cout << ',';
            }

            const std::string field_name =
                fusion::extension::struct_member_name<Sequence, Index::value>::call();

            // std::cout << fusion::at<Index>(seq_);

            // It doesn't work now :(
            // error: invalid operands to binary expression ('basic_ostream<char>' and 'typename
            // result_of::at<const StructWithPrivate, integral_c<unsigned int, 0>>::type'
            // (aka 'adt_attribute_proxy<advanced::StructWithPrivate, 0, is_const<const StructWithPrivate>::value>'))

            const auto fieldValue = fusion::at<Index>(seq_).get();

            std::cout
                << '"' << field_name << '"'
                << ':'
                << '"' << fieldValue << '"';
        }

    private:
        const Sequence& seq_;
    };

    template <typename Sequence>
    void printJson(Sequence const& v) {
        std::cout << '{';
        typedef mpl::range_c<unsigned, 0, fusion::result_of::size<Sequence>::value> Indices;
        fusion::for_each(Indices(), JsonFieldNamePrinter<Sequence>(v));
        std::cout << '}';
    }

    void example() {
        std::cout << "*****     advanced example    ****" << std::endl;
        StructWithPrivate saveMe = {"Hello, World!", 42};
        printJson(saveMe);
    }

}

int main() {
    basics::example();
    std::cout << std::endl << std::endl;

    advanced::example();
    std::cout << std::endl << std::endl;
}
